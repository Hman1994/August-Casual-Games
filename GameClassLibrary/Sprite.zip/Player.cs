﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameClassLibrary
{
    public class Player : Sprite
    {
        static int ID = 1;
        int PlayerID;
        public Character PlayerChar;
        public Vector2 Position;
        public Vector2 FireDirection = new Vector2(1,0);
        public Color playerColor;
        Texture2D healthBar;
        Game game;


        public Player() : base()
        {

        }

        public Player(Character character, Texture2D health, Vector2 pos, Color c, Game g) : base(character._texture, pos) //create the player
        {
            PlayerID = ID++;
            PlayerChar = character;
            Position = pos;
            healthBar = health;
            playerColor = c;
            game = g;
        }

        public void Move(KeyboardState state)
        {
            if (state.IsKeyDown(Keys.W) && Position.Y > 0) //check the move direction and update position
            {
                Position.Y -= PlayerChar.movementSpeed; 
                FireDirection = new Vector2(0, -1);
            }
            if (state.IsKeyDown(Keys.S) && Position.Y < 550)
            {
                Position.Y += PlayerChar.movementSpeed;
                FireDirection = new Vector2(0,1);
            }
            if (state.IsKeyDown(Keys.D) && Position.X < 760)
            {
                Position.X += PlayerChar.movementSpeed;
                FireDirection = new Vector2(1, 0);
            }
            if (state.IsKeyDown(Keys.A) && Position.X > 0)
            {
                Position.X -= PlayerChar.movementSpeed;
                FireDirection = new Vector2(-1, 0);
            }
            //if (state.IsKeyDown(Keys.Space))
            //    PlayerChar.Shoot(FireDirection, game);
        }

        public void Update()
        {
            
        }

        public override void Draw(SpriteBatch sp)
        {
            sp.Begin();
            sp.Draw(PlayerChar._texture, Position, playerColor); //draw the player
            sp.Draw(healthBar, new Rectangle((int)Position.X , (int)Position.Y + _texture.Height + 2, healthBar.Width, healthBar.Height), Color.Red); //draw the negative HealthBar
            sp.Draw(healthBar, new Rectangle((int)Position.X , (int)Position.Y + _texture.Height + 2, (int)(healthBar.Width * ((double)PlayerChar.Health / 100)), healthBar.Height), Color.Green); //calculate and draw the positive HealthBar above 
            //sp.Draw(healthBar, Position + new Vector2(_texture.Width - healthBar.Width, _texture.Height * 2) / 2, Color.Red);
            //sp.Draw(healthBar, Position + new Vector2(_texture.Width - healthBar.Width, _texture.Height * 2) / 2, Color.Green);
            sp.End();
        }
    }
}
