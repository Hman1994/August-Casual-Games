﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameClassLibrary
{
    public class Sprite
    {
        public Texture2D _texture{ get; set; }
        public Vector2 _position { get; set; }
        public Rectangle rectangle;
        public bool IsVisible;

        public Sprite()
        {}

        public Sprite(Texture2D _tex, Vector2 _pos)
        {
            _texture = _tex;
            _position = _pos;
            IsVisible = true;
        }

        public Rectangle GetRectangle()
        {
            return new Rectangle((int)_position.X, (int)_position.Y, _texture.Width, _texture.Height);
        }
        
        public virtual void Draw(SpriteBatch sp)
        {
            sp.Begin();
            if (_texture != null && IsVisible)
                sp.Draw(_texture, _position, Color.White);
            sp.End();
        }

        public virtual void Draw(SpriteBatch sp, float layer)
        {
            sp.Begin();
            if (_texture != null)
                sp.Draw(_texture, _position, null, Color.White, 0f, Vector2.Zero, 1, SpriteEffects.None, layer);
            sp.End();
        }

        public bool CollisiionDetection(Rectangle otherRec)
        {
            if (this.GetRectangle().Intersects(otherRec))
                return true;
            else
                return false;
        }
    }
}
