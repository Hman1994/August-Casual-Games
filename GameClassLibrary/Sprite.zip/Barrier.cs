﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameClassLibrary
{
    public class Barrier : Sprite
    {
        int health;
        Texture2D[] textures;

        public Barrier(Texture2D tex, Vector2 pos): base(tex, pos)
        {
            health = 15;
        }

        public Barrier(Texture2D[] tex, Vector2 pos): base(tex[0], pos)
        {
            textures = tex;
            health = 15;
        }

        public void GotHit(Bullet bull)
        {
            health -= bull.damage;
            if (health < 8)
                _texture = textures[1];
        }



    }
}
